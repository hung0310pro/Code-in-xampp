<h1>Index</h1>
<?php

echo '<pre>'.__FILE__.'::'.__METHOD__.'('.__LINE__.')';
	print_r($_GET);
echo '</pre>';