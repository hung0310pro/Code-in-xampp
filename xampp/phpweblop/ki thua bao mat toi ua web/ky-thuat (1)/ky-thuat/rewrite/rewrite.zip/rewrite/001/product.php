<?php
echo '<h1>Product </h1>';

echo 'ID nhóm sản phẩm: '. $_GET['catid'];

echo '<br>ID sản phẩm: '. $_GET['pid'] ;

